const netflix = [
  {
    "identificador": 758690,
    "título": "The king:Eterno monarca",
    "Año": "2020",
    "Capítulos": "16",
    "Temporadas": "1",
    "clasificación": "Tv-14",
    "género": "Ficción,Romance",
    "director": "*****",
    "protagonistas": [
      "Lee min-ho",
      "amy adams"
    ],
    "descripción": "Mientras Lee Gon llora la trágica muerte su padre Lee Min halla una inesperada escapatoria al toparse con una puerta que conduce a un universo paralelo"
  },
  {
    "identificador": 645372,
    "título": "El mundo oculto de sabrina",
    "Año": "2020",
    "Capítulos": "28",
    "Temporadas": "3",
    "clasificación": "Tv-14",
    "género": "Fantasía,Romance",
    "director": "*****",
    "protagonistas": [
      "Kiernan Shipka",
      "Ross Lynch",
      "Miranda Otto"
    ],
    "descripción": "Mientras  Greendale se prepara para un eclipse de Hallovween, Sabrina debe tomar uan decisión difícil, y Harvey hace una declaración inesperada"
  },
  {
    "identificador": 284637,
    "título": "Élite",
    "Año": "2020",
    "Capítulos": "24",
    "Temporadas": "3",
    "clasificación": "Tv-MA",
    "género": "Drama,Misterio,Romance",
    "director": "Carlos Montero",
    "protagonistas": [
      "Danna Paola",
      "Ester Exposito",
      "Jorge Lopez",
      "Aron Piper"
    ],
    "descripción": "Tras el colapso de una escuela pública, el constructor intenta subsanar el daño de a su imagen con una beca a tres estudiantes para que asistan a una institucion privada"
  },
  {
    "identificador": 930173,
    "título": "Sex education",
    "Año": "2020",
    "Capítulos": "16",
    "Temporadas": "2",
    "clasificación": "Tv-MA",
    "género": "Drama",
    "director": "Laurie Nunn",
    "protagonistas": [
      "Asa Butterfield",
      "Gilian Anderson",
      "Mimi Keene"
    ],
    "descripción": "Por tener una mandre terapeuta, Otis siempre tiene una respuesta cuando de sexo se trara.Así que su rebelde amiga Meave le propone abrir una clínica de terapia sexual"
  },
  {
    "identificador": 124370,
    "título": "Insatiable",
    "Año": "2020",
    "Capítulos": "22",
    "Temporadas": "2",
    "clasificación": "Tv-MA",
    "género": "Drama, Comedia",
    "director": "...",
    "protagonistas": [
      "Debby Ryan",
      "Alyssa Milano"
    ],
    "descripción": "Una adolescente que fue víctima de acoso escolar se anota en un concurso de belleza para vengarse, con la ayuda de un desdichado entrenador que no sabe en la que se metió"
  },
  {
    "identificador": 579034,
    "título": "Dark",
    "Año": "2017",
    "Capítulos": "18",
    "Temporadas": "2",
    "clasificación": "Tv-MA",
    "género": "Crimen,Drama , Misterio",
    "director": "Baran bo Odar",
    "protagonistas": [
      "Jördis Triebel",
      "Louis Hofmann",
      "Karoline Eichhorn "
    ],
    "descripción": "Una saga familiar con un toque sobrenatural, ambientada en una ciudad alemana, donde la desaparición de dos niños pequeños expone las relaciones entre cuatro familias."
  },
  {
    "identificador": 576543,
    "título": "Locke & Key",
    "Año": "2017",
    "Capítulos": "10",
    "Temporadas": "1",
    "clasificación": "Tv-MA",
    "género": "Drama , Fantasía , Horror ",
    "director": "Meredith Averill",
    "protagonistas": [
      " Darby Stanchfield",
      "Connor Jessup",
      "Emilia Jones "
    ],
    "descripción": "Después de que su padre es asesinado en circunstancias misteriosas, los tres hermanos Locke ysu madre se mudan a su hogar ancestral, Keyhouse, que descubren que está lleno de llaves mágicas que pueden estar relacionadas con la muerte de su padre."
  },
  {
    "identificador": 346543,
    "título": "Titans ",
    "Año": "2019",
    "Capítulos": "10",
    "Temporadas": "1",
    "clasificación": "Tv-MA",
    "género": "Acción , Aventura , Crimen  ",
    "director": " Greg Berlanti",
    "protagonistas": [
      " Anna Diop",
      " Teagan Croft",
      "Brenton Thwaites "
    ],
    "descripción": "Un equipo de jóvenes superhéroes combate el mal y otros peligros."
  }
]